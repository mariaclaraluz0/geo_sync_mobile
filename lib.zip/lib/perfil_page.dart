import 'package:flutter/material.dart';

class PerfilMotoristaPage extends StatelessWidget {
  const PerfilMotoristaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F6),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0B2A4A),
        title: const Text("GeoSync"),
        actions: const [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Center(child: Text("Motorista")),
          ),
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(child: Text("Relatórios")),
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            /// TÍTULO
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Perfil do Motorista",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 6),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Informações completas do motorista e monitoramento em tempo real.",
                style: TextStyle(color: Colors.grey),
              ),
            ),

            const SizedBox(height: 16),

            /// CONTEÚDO
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                /// CARD ESQUERDA (PERFIL)
                Expanded(
                  flex: 4,
                  child: Column(
                    children: [
                      _perfilCard(),
                      const SizedBox(height: 12),
                      _infoCard(Icons.badge, "CNH", "54892734100"),
                      const SizedBox(height: 12),
                      _infoCard(Icons.phone, "Telefone", "(11) 99999-9999"),
                    ],
                  ),
                ),

                const SizedBox(width: 12),

                /// DIREITA
                Expanded(
                  flex: 6,
                  child: Column(
                    children: [
                      _statusVeiculo(),
                      const SizedBox(height: 12),
                      _historico(),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// CARD PERFIL
  Widget _perfilCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Column(
        children: [
          const CircleAvatar(
            radius: 40,
            backgroundColor: Color(0xFFE3EAF4),
            child: Icon(Icons.person, size: 40, color: Colors.blue),
          ),
          const SizedBox(height: 10),
          const Text(
            "Carlos Henrique",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const Text(
            "Motorista Logístico • Transporte Rodoviário",
            style: TextStyle(color: Colors.grey),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                SizedBox(width: 6),
                Text("Motorista em rota"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// CARD INFORMAÇÃO
  Widget _infoCard(IconData icon, String title, String value) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: Colors.blue.withOpacity(0.1),
            child: Icon(icon, color: Colors.blue),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.grey)),
              Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          )
        ],
      ),
    );
  }

  /// STATUS DO VEÍCULO
  Widget _statusVeiculo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.local_shipping, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                "Status do Veículo",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 12),

          Row(
            children: const [
              Expanded(child: _statusItem("Velocidade", "72 km/h")),
              SizedBox(width: 10),
              Expanded(child: _statusItem("Temperatura", "23°C")),
              SizedBox(width: 10),
              Expanded(child: _statusItem("Combustível", "68%")),
            ],
          ),
        ],
      ),
    );
  }

  /// HISTÓRICO
  Widget _historico() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Row(
            children: [
              Icon(Icons.timeline, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                "Histórico de Atividades",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          SizedBox(height: 12),

         
        ],
      ),
    );
  }

  /// ITEM HISTÓRICO
  static Widget _timelineItem(String title, String subtitle) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(radius: 5, backgroundColor: Colors.blue),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                Text(subtitle, style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// DECORAÇÃO PADRÃO
  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      boxShadow: const [
        BoxShadow(color: Colors.black12, blurRadius: 4)
      ],
    );
  }
}